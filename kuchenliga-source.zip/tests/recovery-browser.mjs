import {chromium} from 'playwright';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
const root=new URL('../',import.meta.url).pathname;
const server=spawn(process.execPath,['scripts/serve.mjs','dist'],{cwd:root,env:{...process.env,PORT:'4184'},stdio:'pipe'});
const browser=await chromium.launch({headless:true});
try{
 for(let i=0;i<40;i++){try{if((await fetch('http://localhost:4184/passwort.html')).ok)break;}catch{}await new Promise(r=>setTimeout(r,100));}
 const page=await browser.newPage({viewport:{width:390,height:844}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 let verified=0,updated=0,expired=false;
 await page.route('https://*.supabase.co/auth/v1/**',async route=>{
  const request=route.request(),data=request.postDataJSON();
  if(request.url().endsWith('/verify')){verified++;assert.deepEqual(data,{token_hash:'test-token',type:'recovery'});await route.fulfill({headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*'},status:expired?403:200,contentType:'application/json',body:JSON.stringify(expired?{msg:'expired'}:{access_token:'test-session'})});}
  else{updated++;assert.equal(request.headers().authorization,'Bearer test-session');assert.equal(data.password,'test-only-password-123');await route.fulfill({headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*'},status:200,contentType:'application/json',body:'{"id":"existing-account"}'});}
 });
 await page.goto('http://localhost:4184/passwort.html');await page.getByRole('alert').waitFor();assert.equal(await page.locator('#reset-form').isVisible(),false);
 await page.goto('http://localhost:4184/passwort.html#token_hash=test-token');await page.locator('#reset-password').waitFor();await page.waitForURL('http://localhost:4184/passwort.html');assert.equal(verified,0);
 await page.getByLabel('Neues Passwort',{exact:true}).fill('test-only-password-123');await page.getByLabel('Passwort wiederholen').fill('different-password-123');await page.getByRole('button',{name:'Neues Passwort speichern'}).click();await page.getByText('Die beiden Passwörter stimmen nicht überein.').waitFor();assert.equal(verified,0);assert.equal(updated,0);
 await page.getByLabel('Passwort wiederholen').fill('test-only-password-123');await page.getByRole('button',{name:'Neues Passwort speichern'}).click();await page.getByRole('status').waitFor({timeout:5000}).catch(async e=>{console.log({error:await page.locator('#error').textContent(),verified,updated,errors});throw e;});assert.equal(verified,1);assert.equal(updated,1);assert.equal(await page.locator('#reset-form').isVisible(),false);assert.equal(await page.evaluate(()=>localStorage.length+sessionStorage.length),0);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 expired=true;await page.goto('http://localhost:4184/passwort.html#token_hash=test-token');await page.getByLabel('Neues Passwort',{exact:true}).fill('test-only-password-123');await page.getByLabel('Passwort wiederholen').fill('test-only-password-123');await page.getByRole('button',{name:'Neues Passwort speichern'}).click();await page.getByText(/abgelaufen oder wurde bereits verwendet/).waitFor();assert.equal(updated,1);assert.deepEqual(errors,[]);
 console.log('Recovery browser: missing token, untouched token on open, mismatch, success, expired link, no credential storage, phone layout: PASS');
}finally{await browser.close();server.kill();}

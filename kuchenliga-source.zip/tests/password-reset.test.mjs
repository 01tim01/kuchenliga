import test from 'node:test';
import assert from 'node:assert/strict';
const module=await import('../src/password-reset.js').catch(()=>({}));
const setup=()=>{assert.equal(typeof module.PasswordReset,'function','password recovery client must exist');const calls=[];const flow=new module.PasswordReset({supabaseUrl:'https://test.supabase.co',publishableKey:'public'},'valid-token',async(url,opts)=>{calls.push({url,opts,body:JSON.parse(opts.body)});return new Response(JSON.stringify(url.endsWith('/verify')?{access_token:'recovered-session'}:{id:'existing-member'}),{status:200});});return {flow,calls};};
test('password recovery rejects mismatches and weak passwords before exchanging its token',async()=>{
 const {flow,calls}=setup();await assert.rejects(flow.save('short','short'),/12/);await assert.rejects(flow.save('a-long-password','different'),/überein/);assert.equal(calls.length,0);
});
test('password recovery verifies type recovery before updating the same existing account',async()=>{
 const {flow,calls}=setup();await flow.save('a-long-password','a-long-password');assert.equal(calls.length,2);assert.deepEqual(calls[0].body,{token_hash:'valid-token',type:'recovery'});assert.equal(calls[1].opts.method,'PUT');assert.equal(calls[1].opts.headers.Authorization,'Bearer recovered-session');assert.deepEqual(calls[1].body,{password:'a-long-password'});await assert.rejects(flow.save('a-long-password','a-long-password'),/bereits/);assert.equal(calls.length,2);
});
test('expired links never send a password update',async()=>{
 assert.equal(typeof module.PasswordReset,'function');let calls=0;const flow=new module.PasswordReset({supabaseUrl:'https://test.supabase.co',publishableKey:'public'},'expired',async()=>{calls++;return new Response(JSON.stringify({msg:'expired'}),{status:403});});await assert.rejects(flow.save('a-long-password','a-long-password'),/abgelaufen|verwendet/);assert.equal(calls,1);
});
test('a retry after a password validation error reuses only the in-memory recovered session',async()=>{
 assert.equal(typeof module.PasswordReset,'function');let verified=0,updated=0;const flow=new module.PasswordReset({supabaseUrl:'https://test.supabase.co',publishableKey:'public'},'valid',async(url)=>{if(url.endsWith('/verify')){verified++;return Response.json({access_token:'session'});}updated++;return Response.json(updated===1?{msg:'Password is too weak'}:{id:'same-member'},{status:updated===1?422:200});});await assert.rejects(flow.save('a-long-password','a-long-password'),/schwach|stärker/);await flow.save('another-long-password','another-long-password');assert.equal(verified,1);assert.equal(updated,2);
});

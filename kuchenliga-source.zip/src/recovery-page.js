import {CONFIG} from '../config.js';
import {PasswordReset} from './password-reset.js';
const $=s=>document.querySelector(s),params=new URLSearchParams(location.hash.slice(1));
const token=params.get('token_hash');
// Remove bearer links from the current history entry immediately.
history.replaceState(null,'',location.pathname);
window.addEventListener('hashchange',()=>{if(location.hash)location.reload();});
const error=message=>{$('#error').textContent=message;$('#error').hidden=!message;};
if(token){
 const flow=new PasswordReset(CONFIG,token);let busy=false;
 $('#reset-form').addEventListener('submit',async event=>{
  event.preventDefault();if(busy)return;busy=true;$('#reset-submit').disabled=true;error('');
  try{await flow.save($('#reset-password').value,$('#reset-repeat').value);$('#reset-password').value='';$('#reset-repeat').value='';$('#reset-form').hidden=true;$('#success').textContent='Dein neues Passwort ist gespeichert. Melde dich mit deinem Namen und dem neuen Passwort an.';$('#success').hidden=false;}
  catch(e){error(e.message);}finally{busy=false;$('#reset-submit').disabled=false;}
 });
}else{$('#reset-form').hidden=true;error('Bitte öffne deinen persönlichen Wiederherstellungslink.');}

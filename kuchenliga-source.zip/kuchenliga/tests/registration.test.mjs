import test from 'node:test';
import assert from 'node:assert/strict';
const module=await import('../supabase/functions/register/index.ts').catch(()=>({}));
const token='a'.repeat(43),origin='https://01tim01.github.io';
const env={SUPABASE_URL:'https://class.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'server-only-key'};
const req=body=>new Request('https://class.supabase.co/functions/v1/register',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
test('registration rejects malformed token and weak password before touching account',async()=>{
 assert.equal(typeof module.handleRegistration,'function');
 const unexpected=()=>{throw Error('Remote API must not be called');};
 assert.equal((await module.handleRegistration(req({token:'short',password:'long-enough-password'}),env,unexpected)).status,400);
 assert.equal((await module.handleRegistration(req({token,password:'short'}),env,unexpected)).status,400);
});
test('registration consumes invite once, changes only its user password and records activation',async()=>{
 assert.equal(typeof module.handleRegistration,'function');let consumed=false;const calls=[];
 const remote=async(url,options)=>{
  calls.push({url,body:options.body?JSON.parse(options.body):null});
  let result=[];
  if(url.endsWith('/rpc/consume_registration_invite')){result=consumed?[]:[{user_id:'invited-user',display_name:'Tim',login_id:'tim'}];consumed=true;}
  if(url.endsWith('/rpc/complete_registration_invite'))result=true;
  if(url.includes('/admin/users/')){assert.ok(url.endsWith('/invited-user'));assert.deepEqual(JSON.parse(options.body),{password:'my-private-password'});result={id:'invited-user'};}
  return new Response(JSON.stringify(result),{status:200});
 };
 const response=await module.handleRegistration(req({token,password:'my-private-password'}),env,remote);assert.equal(response.status,200);
 const data=await response.json();assert.equal(data.login_id,'tim');assert.ok(!JSON.stringify(data).includes('server-only-key'));
 assert.equal((await module.handleRegistration(req({token,password:'another-private-password'}),env,remote)).status,409);
 assert.equal(calls.filter(c=>c.url.includes('/admin/users/')).length,1);
 assert.ok(calls.some(c=>c.url.endsWith('/rpc/complete_registration_invite')&&c.body.p_claim_id));
});
test('temporary Auth failure releases the invite claim and permits a successful retry',async()=>{
 let claimed=false,completed=false,fail=true;
 const remote=async(url)=>{
  let data=null,status=200;
  if(url.endsWith('/consume_registration_invite')){data=claimed||completed?[]:[{user_id:'u',display_name:'Tim',login_id:'tim'}];claimed=true;}
  if(url.includes('/admin/users/')){status=fail?503:200;fail=false;data={id:'u'};}
  if(url.endsWith('/release_registration_invite'))claimed=false;
  if(url.endsWith('/complete_registration_invite')){completed=true;data=true;}
  return new Response(JSON.stringify(data),{status});
 };
 assert.equal((await module.handleRegistration(req({token,password:'my-private-password'}),env,remote)).status,503);
 assert.equal(claimed,false);
 assert.equal((await module.handleRegistration(req({token,password:'my-private-password'}),env,remote)).status,200);
 assert.equal(completed,true);
});

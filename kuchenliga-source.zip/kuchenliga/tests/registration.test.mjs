import test from 'node:test';
import assert from 'node:assert/strict';
import {handleRegistration} from '../supabase/functions/register/index.ts';
const env={SUPABASE_URL:'https://class.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'server-only-key'};
const req=body=>new Request('https://class.supabase.co/functions/v1/register',{method:'POST',headers:{Origin:'https://01tim01.github.io','Content-Type':'application/json'},body:JSON.stringify(body)});
test('free registration rejects invalid name or password without touching an account',async()=>{
 const unexpected=()=>{throw Error('Remote API must not be called');};
 for(const body of [{action:'signup',login_id:'',password:'my-private-password'},{action:'signup',login_id:'tim',password:'short'},{token:'a'.repeat(43),password:'my-private-password'}])assert.equal((await handleRegistration(req(body),env,unexpected)).status,400);
});
test('a free class slot gets a chosen password once; registered accounts cannot be overwritten',async()=>{
 let active=false;const calls=[];
 const remote=async(url,options)=>{
  calls.push({url,body:options.body&&JSON.parse(options.body)});let data=[];
  if(url.endsWith('/claim_free_registration'))data=active?[]:[{user_id:'tim-id',display_name:'Tim',login_id:'tim'}];
  if(url.endsWith('/finish_free_registration')){active=true;data=true;}
  if(url.includes('/admin/users/')){assert.ok(url.endsWith('/tim-id'));assert.deepEqual(JSON.parse(options.body),{password:'my-new-password'});data={id:'tim-id'};}
  return new Response(JSON.stringify(data));
 };
 const response=await handleRegistration(req({action:'signup',login_id:'tim',password:'my-new-password'}),env,remote);assert.equal(response.status,200);assert.equal((await response.json()).login_id,'tim');
 assert.equal((await handleRegistration(req({action:'signup',login_id:'tim',password:'other-new-password'}),env,remote)).status,409);
 assert.equal(calls.filter(c=>c.url.includes('/admin/users/')).length,1);
});
test('temporary failure releases the name reservation and permits a successful retry',async()=>{
 let claimed=false,active=false,fail=true;
 const remote=async(url)=>{let data=null,status=200;
  if(url.endsWith('/claim_free_registration')){data=claimed||active?[]:[{user_id:'u',display_name:'Tim',login_id:'tim'}];claimed=true;}
  if(url.includes('/admin/users/')){status=fail?503:200;fail=false;data={id:'u'};}
  if(url.endsWith('/release_free_registration'))claimed=false;
  if(url.endsWith('/finish_free_registration')){active=true;data=true;}
  return new Response(JSON.stringify(data),{status});
 };
 const body={action:'signup',login_id:'tim',password:'my-private-password'};
 assert.equal((await handleRegistration(req(body),env,remote)).status,503);assert.equal(claimed,false);
 assert.equal((await handleRegistration(req(body),env,remote)).status,200);assert.equal(active,true);
});

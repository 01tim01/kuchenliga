import {chromium} from 'playwright';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {mkdir} from 'node:fs/promises';
const root=new URL('../',import.meta.url).pathname;
const server=spawn(process.execPath,['scripts/serve.mjs',process.env.TEST_SITE_DIR||'.'],{cwd:root,env:{...process.env,PORT:'4183'},stdio:'pipe'});
const browser=await chromium.launch({headless:true});
let passed=0;
try {
  for(let i=0;i<40;i++){try{if((await fetch('http://localhost:4183')).ok)break;}catch{} await new Promise(r=>setTimeout(r,100));}
  const page=await browser.newPage({viewport:{width:1440,height:1000}});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/config.js',route=>route.fulfill({contentType:'application/javascript',body:"export const CONFIG={supabaseUrl:'',publishableKey:''};"}));
  await page.goto('http://localhost:4183');
  await page.locator('.cake-card').last().waitFor();
  assert.equal(await page.locator('.cake-card').count(),9);
  await page.getByRole('button',{name:'Nico bewerten'}).click();
  await page.getByRole('dialog').waitFor();
  assert.ok(await page.getByText('Vorschau: Es werden keine Stimmen gespeichert.').isVisible());
  await page.getByRole('button',{name:'8 Punkte',exact:true}).click();
  assert.equal(await page.getByRole('button',{name:'Verbindlich bewerten'}).isEnabled(),false);
  await page.getByRole('button',{name:'Schliessen',exact:true}).click();
  await page.getByRole('button',{name:'Aktueller Stand',exact:true}).click();
  assert.ok(await page.getByText('Noch ist alles offen.').isVisible());passed++;
  await page.setViewportSize({width:390,height:844});
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth));
  await page.getByRole('button',{name:'Kuchen',exact:true}).click();
  await mkdir(new URL('../screenshots/',import.meta.url),{recursive:true});
  await page.screenshot({path:root+'screenshots/mobile.png',fullPage:true});
  await page.setViewportSize({width:1440,height:1000});
  await page.screenshot({path:root+'screenshots/desktop.png',fullPage:true});passed++;

  // Stub only the remote HTTP service; the application, DOM and all interaction are real.
  let votes=[]; let inserts=0; let failSave=false; let duplicate=false;let profile={avatar:'🍰',color:'#eaf3fc'};let currentLogin='tim';let releaseLoad=null;let delayed=false;
  await page.unroute('**/config.js');
  await page.route('**/config.js',route=>route.fulfill({contentType:'application/javascript',body:"export const CONFIG={supabaseUrl:'https://class.supabase.co',publishableKey:'sb_publishable_test'};"}));
  await page.route('https://class.supabase.co/**',async route=>{
    const req=route.request(), url=new URL(req.url());
    let body={},status=200;
    if(url.pathname.endsWith('/token')) {if(req.postDataJSON().email)currentLogin=req.postDataJSON().email.split('@')[0];body={access_token:'test-token',refresh_token:'test-refresh',expires_in:3600,user:{id:'11111111-1111-4111-8111-111111111111'}};}
    else if(url.pathname.endsWith('/members')) body=[{participant_id:currentLogin==='berni'?null:currentLogin,login_id:currentLogin,display_name:currentLogin==='berni'?'Berni':'Tim'}];
    else if(url.pathname.endsWith('/leaderboard')) body=['nico','livio','kimo','kyle','noemi','maria','anina','joel-haeusler','tim'].map(id=>({id,baking_date:id==='kimo'?'2100-11-27':'2020-01-01',avatar:profile.avatar,color:profile.color,name:({'joel-haeusler':'Joel Häusler'})[id]||id[0].toUpperCase()+id.slice(1),average:votes.some(v=>v.target_id===id)?8:null,vote_count:votes.filter(v=>v.target_id===id).length}));
    else if(url.pathname.endsWith('/votes') && req.method()==='POST'){
      inserts++; if(failSave){status=503;body={message:'Unavailable'};}
      else if(duplicate){status=409;body={code:'23505',message:'duplicate key'};votes.push({target_id:'nico',score:8});}
      else {const v=req.postDataJSON(); assert.equal(v.score,8); assert.equal(v.voter_id,'11111111-1111-4111-8111-111111111111'); votes.push(v);body=[v];status=201;}
    } else if(url.pathname.endsWith('/votes')) {body=votes;if(delayed){delayed=false;await new Promise(r=>releaseLoad=r);}}
    else if(url.pathname.endsWith('/profiles')){if(req.method()==='PATCH'||req.method()==='POST')profile=req.postDataJSON();body=[profile];}
    await route.fulfill({status,contentType:'application/json',body:JSON.stringify(body),headers:{'access-control-allow-origin':'*'}});
  });
  await page.reload(); await page.getByRole('button',{name:'Anmelden',exact:true}).first().click();
  await page.getByLabel('Dein Name').selectOption('tim');await page.getByLabel('Dein Passwort').fill('some-private-password');
  await page.getByRole('button',{name:'Jetzt anmelden'}).click();
  await page.getByRole('button',{name:'Abmelden'}).waitFor();
  assert.ok(await page.getByText('Dein eigener Kuchen').isVisible());passed++;
  await page.getByRole('button',{name:'Livio bewerten'}).click();await page.getByRole('button',{name:'8 Punkte',exact:true}).click();
  await page.getByLabel('Ich bestätige meine endgültige Bewertung.').check();
  await page.getByRole('button',{name:'Verbindlich bewerten'}).click();
  await page.getByText('Deine 8 Punkte sind gespeichert.').waitFor();
  assert.equal(inserts,1); assert.ok(await page.getByText('Deine Wertung: 8/10').isVisible());
  await page.reload();await page.getByText('Deine Wertung: 8/10').waitFor();assert.equal(inserts,1);passed++;
  failSave=true;
  await page.getByRole('button',{name:'Nico bewerten'}).click();await page.getByRole('button',{name:'8 Punkte',exact:true}).click();
  await page.getByLabel('Ich bestätige meine endgültige Bewertung.').check();await page.getByRole('button',{name:'Verbindlich bewerten'}).click();
  await page.getByText('Speichern nicht bestätigt. Bitte nochmals versuchen.').waitFor();
  assert.ok(await page.getByRole('button',{name:'Verbindlich bewerten'}).isEnabled());
  failSave=false;duplicate=true;await page.getByRole('button',{name:'Verbindlich bewerten'}).click();
  await page.getByText('Dieser Kuchen wurde bereits bewertet. Deine gespeicherte Wertung wird geladen.').waitFor();
  await page.getByRole('button',{name:'Schliessen',exact:true}).click();
  assert.equal(await page.getByText('Deine Wertung: 8/10').count(),2);passed++;
  assert.equal(await page.getByRole('button',{name:'Kimo: ab 27.11.2100'}).isEnabled(),false);passed++;
  await page.getByRole('button',{name:'Profil bearbeiten'}).click();
  await page.getByRole('button',{name:'Avatar 🦊',exact:true}).click();
  await page.getByRole('button',{name:'Farbe Mint'}).click();
  await page.getByRole('button',{name:'Profil speichern'}).click();await page.getByText('Dein Profil ist gespeichert.').waitFor();
  await page.reload();await page.getByRole('button',{name:'Profil bearbeiten'}).click();
  assert.equal(await page.getByRole('button',{name:'Avatar 🦊',exact:true}).getAttribute('aria-pressed'),'true');
  await page.getByRole('button',{name:'Schliessen',exact:true}).click();passed++;
  assert.equal(await page.locator('.main-nav button').count(),2);assert.equal(await page.locator('#mode-banner').isVisible(),false);passed++;
  // Regression: a delayed authenticated load may not restore private labels after logout.
  delayed=true;await page.getByRole('button',{name:'Aktueller Stand',exact:true}).click();await page.getByRole('button',{name:'Aktualisieren'}).click();
  for(let i=0;i<30&&!releaseLoad;i++)await new Promise(r=>setTimeout(r,20));assert.ok(releaseLoad);
  await page.getByRole('button',{name:'Abmelden'}).click();releaseLoad();
  await page.getByRole('button',{name:'Anmelden',exact:true}).first().waitFor();
  await page.waitForTimeout(100);await page.getByRole('button',{name:'Kuchen',exact:true}).click();
  assert.equal(await page.getByText('Deine Wertung: 8/10').count(),0);passed++;
  await page.getByRole('button',{name:'Anmelden',exact:true}).first().click();
  await page.getByLabel('Dein Name').selectOption('berni');await page.getByLabel('Dein Passwort').fill('some-private-password');
  await page.getByRole('button',{name:'Jetzt anmelden'}).click();await page.getByRole('button',{name:'Abmelden'}).waitFor();
  assert.equal(await page.getByText('Dein eigener Kuchen').count(),0);assert.ok(await page.getByText('2 von 9 bewertet').isVisible());
  await page.getByRole('button',{name:'Abmelden'}).click();passed++;

  assert.equal(await page.getByText('Deine Wertung: 8/10').count(),0);assert.equal(errors.length,0,errors.join('\n'));passed++;
  console.log(`${passed} browser scenarios passed (preview, responsive, login, persisted vote, failures/duplicate, logout).`);
} finally {await browser.close();server.kill();}

import test from 'node:test';
import assert from 'node:assert/strict';
const domain = await import('../src/domain.js').catch(() => ({}));
test('cake list excludes non-bakers, includes Maria and member list distinguishes both Joels', () => {
  assert.equal(domain.ROSTER?.length, 9);
  assert.equal(domain.MEMBERS?.length,12);
  assert.ok(domain.ROSTER.some(p=>p.name==='Maria'));
  assert.ok(!domain.ROSTER.some(p=>['Berni','Joel Stocker','Raphael'].includes(p.name)));
  assert.equal(domain.ROSTER.filter(p => p.name === 'Noemi').length, 1);
  assert.ok(domain.MEMBERS.some(p => p.name === 'Joel Stocker'));
  assert.ok(domain.ROSTER.some(p => p.name === 'Joel Häusler'));
});
test('vote requires an integer score from 1 through 10', () => {
  assert.equal(typeof domain.validateVote, 'function');
  for (const score of [0, 11, 1.5, '8', NaN, null]) assert.throws(() => domain.validateVote({score,voterId:'a',targetId:'b',votes:[]}));
  for (const score of [1,10]) assert.doesNotThrow(() => domain.validateVote({score,voterId:'a',targetId:'b',votes:[]}));
});
test('self voting and duplicate voting are rejected', () => {
  assert.equal(typeof domain.validateVote, 'function');
  assert.throws(() => domain.validateVote({score:8,voterId:'a',targetId:'a',votes:[]}));
  assert.throws(() => domain.validateVote({score:8,voterId:'a',targetId:'b',votes:[{target_id:'b',score:7}]}));
});
test('ranking uses exact averages and equal ranks on ties; empty cakes have no rank', () => {
  assert.equal(typeof domain.rankCakes, 'function');
  const ranked = domain.rankCakes([{id:'a',name:'A',average:8,vote_count:2},{id:'b',name:'B',average:9,vote_count:1},{id:'c',name:'C',average:8,vote_count:1},{id:'d',name:'D',average:null,vote_count:0}]);
  assert.deepEqual(ranked.map(p => [p.id,p.rank]), [['b',1],['a',2],['c',2],['d',null]]);
});
test('release date uses Swiss calendar day across midnight and opens inclusively',()=>{
 assert.equal(domain.swissToday(new Date('2026-11-26T23:30:00Z')),'2026-11-27');
 assert.equal(domain.isOpen({date:'2026-11-27'},'2026-11-26'),false);
 assert.equal(domain.isOpen({date:'2026-11-27'},'2026-11-27'),true);
 assert.equal(domain.isOpen({date:null},'2026-11-27'),false);
});

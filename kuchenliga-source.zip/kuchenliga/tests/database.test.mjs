import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';

// The real SQL schema runs against Postgres, including real roles and RLS.
const schema = await readFile(new URL('../supabase/schema.sql',import.meta.url),'utf8').catch(() => '');
const alice='11111111-1111-4111-8111-111111111111';
const bob='22222222-2222-4222-8222-222222222222';
const outsider='33333333-3333-4333-8333-333333333333';
async function setup(t) {
  assert.ok(schema.length > 0, 'database schema must exist');
  const db=new PGlite(); t.after(() => db.close());
  await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
    create schema auth; create table auth.users (id uuid primary key);
    create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
    grant usage on schema auth to anon,authenticated; grant execute on function auth.uid() to anon,authenticated;`);
  await db.exec(schema);
  await db.exec(`insert into auth.users values ('${alice}'),('${bob}'),('${outsider}');
    insert into public.members(user_id,participant_id) values ('${alice}','tim'),('${bob}','livio');
    update public.participants set baking_date='2020-01-01';`);
  return db;
}
async function asUser(db,id,query) {
  await db.exec(`reset role; set role authenticated; select set_config('request.jwt.claim.sub','${id}',false)`);
  return db.query(query);
}
const insert = (voter,target,score) => `insert into public.votes(voter_id,target_id,score) values ('${voter}','${target}',${score}) returning *`;
test('database accepts one real class vote, blocks duplicate even across sessions', async t => {
  const db=await setup(t);
  const first=await asUser(db,alice,insert(alice,'livio',8)); assert.equal(Number(first.rows[0].score),8);
  await assert.rejects(asUser(db,alice,insert(alice,'livio',9)), /duplicate key/);
  assert.equal((await asUser(db,alice,'select * from public.votes')).rows.length,1);
});
test('database blocks self voting, forged identity, fractions and scores outside 1–10',async t => {
  const db=await setup(t);
  await assert.rejects(asUser(db,alice,insert(alice,'tim',9)), /row-level security/);
  await assert.rejects(asUser(db,alice,insert(bob,'nico',9)), /row-level security/);
  for (const score of [0,11,1.5]) await assert.rejects(asUser(db,alice,insert(alice,'nico',score)));
});
test('outsiders and anonymous visitors cannot read results or add votes',async t => {
  const db=await setup(t);
  await assert.rejects(asUser(db,outsider,insert(outsider,'nico',9)), /row-level security/);
  await assert.rejects(asUser(db,outsider,'select * from public.leaderboard()'), /Kein Klassenzugang/);
  assert.equal((await asUser(db,outsider,'select * from public.participants')).rows.length,0);
  await db.exec('reset role; set role anon;');
  await assert.rejects(db.query('select * from public.votes'), /permission denied/);
  await assert.rejects(db.query('select * from public.leaderboard()'), /permission denied/);
});
test('votes are private and immutable, aggregates are accurate, users cannot add members',async t => {
  const db=await setup(t);
  await asUser(db,alice,insert(alice,'nico',8)); await asUser(db,bob,insert(bob,'nico',10));
  const rows=(await asUser(db,alice,'select * from public.votes')).rows; assert.equal(rows.length,1); assert.equal(rows[0].voter_id,alice);
  await assert.rejects(asUser(db,alice,'update public.votes set score=1'), /permission denied/);
  await assert.rejects(asUser(db,alice,'delete from public.votes'), /permission denied/);
  await assert.rejects(asUser(db,outsider,`insert into public.members(user_id,participant_id) values ('${outsider}','nico')`), /permission denied/);
  await assert.rejects(asUser(db,alice,"update public.participants set name='Fake'"), /permission denied/);
  const ranking=(await asUser(db,alice,'select * from public.leaderboard()')).rows;
  const nico=ranking.find(r=>r.id==='nico'); assert.equal(Number(nico.average),9); assert.equal(Number(nico.vote_count),2);
  assert.equal(ranking.length,9);
  assert.equal((await asUser(db,alice,'select * from public.members')).rows.length,1);
});
test('teacher can vote for every student without owning a cake; profiles are restricted to owner and approved options',async t=>{
  const db=await setup(t);
  await db.exec(`reset role; insert into public.members(user_id,participant_id,display_name) values ('${outsider}',null,'Berni')`);
  await asUser(db,outsider,insert(outsider,'tim',7));
  await asUser(db,outsider,insert(outsider,'livio',10));
  assert.equal((await asUser(db,outsider,'select * from public.leaderboard()')).rows.length,9);
  await asUser(db,alice,`insert into public.profiles(user_id,avatar,color) values ('${alice}','🦊','#e8f2ef')`);
  await assert.rejects(asUser(db,bob,`insert into public.profiles(user_id,avatar,color) values ('${alice}','🐸','#eaf3fc')`));
  assert.equal((await asUser(db,bob,`update public.profiles set avatar='🐸' where user_id='${alice}' returning *`)).rows.length,0);
  await assert.rejects(asUser(db,alice,"update public.profiles set avatar='<script>'"), /check constraint/);
  await assert.rejects(asUser(db,alice,"update public.profiles set color='url(https://evil.test)'"), /check constraint/);
  await asUser(db,alice,"update public.profiles set avatar='🐸'");
  const rows=(await asUser(db,bob,'select * from public.leaderboard()')).rows;
  assert.equal(rows.find(p=>p.id==='tim').avatar,'🐸');
});
test('database blocks future and undated cakes, opens today using the Zurich date',async t=>{
  const db=await setup(t);
  await db.exec("update public.participants set baking_date=(now() at time zone 'Europe/Zurich')::date + 1 where id='nico'");
  await assert.rejects(asUser(db,alice,insert(alice,'nico',8)),/row-level security/);
  await db.exec("reset role; update public.participants set baking_date=null where id='nico'");
  await assert.rejects(asUser(db,alice,insert(alice,'nico',8)),/row-level security/);
  await db.exec("reset role; update public.participants set baking_date=(now() at time zone 'Europe/Zurich')::date where id='nico'");
  await asUser(db,alice,insert(alice,'nico',8));
  assert.equal((await asUser(db,alice,'select * from public.votes')).rows.length,1);
});

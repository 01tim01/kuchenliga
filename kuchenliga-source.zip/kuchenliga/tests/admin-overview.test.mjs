import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
const migration=await readFile(new URL('../supabase/admin-overview.sql',import.meta.url),'utf8').catch(()=> '');
async function setup(t){
 assert.ok(migration,'admin overview must exist');const db=new PGlite();t.after(()=>db.close());
 await db.exec(`create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create table auth.users(id uuid primary key,last_sign_in_at timestamptz);
 create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
 grant usage on schema auth to anon,authenticated;grant execute on function auth.uid() to anon,authenticated;`);
 await db.exec(await readFile(new URL('../supabase/schema.sql',import.meta.url),'utf8'));
 await db.exec(`insert into auth.users(id) values ('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222'),('33333333-3333-4333-8333-333333333333');
 insert into public.members(user_id,participant_id,display_name,login_id,registered_at) values
 ('11111111-1111-4111-8111-111111111111','tim','Tim','tim',now()),
 ('22222222-2222-4222-8222-222222222222','livio','Livio','livio',now()),
 ('33333333-3333-4333-8333-333333333333',null,'Berny','berni',now());
 update public.participants set baking_date='2020-01-01';update public.participants set baking_date='2099-01-01' where id='kimo';
 insert into public.votes(voter_id,target_id,score) values
 ('11111111-1111-4111-8111-111111111111','livio',8),
 ('22222222-2222-4222-8222-222222222222','nico',7),
 ('33333333-3333-4333-8333-333333333333','nico',10),
 ('33333333-3333-4333-8333-333333333333','livio',9);`);
 await db.exec(migration);return db;
}
test('admin matrix shows who rated each cake, open/future/self cells and progress',async t=>{
 const db=await setup(t);const rows=(await db.query('select * from public.admin_bewertungsmatrix')).rows;assert.equal(rows.length,3);
 const tim=rows.find(r=>r.Person==='Tim');assert.equal(tim.Livio,'8');assert.equal(tim.Tim,'—');assert.equal(tim.Kimo,'🔒');assert.equal(tim.Nico,'Offen');assert.equal(Number(tim.Abgegeben),1);assert.equal(Number(tim['Noch offen']),6);
 const berni=rows.find(r=>r.Person==='Berny');assert.equal(berni.Nico,'10');assert.equal(berni.Livio,'9');assert.equal(berni.Tim,'Offen');assert.equal(Number(berni.Abgegeben),2);
 const details=(await db.query('select * from public.admin_einzelbewertungen')).rows;assert.equal(details.length,4);assert.ok(details.some(r=>r['Abgestimmt von']==='Berny'&&r['Kuchen von']==='Nico'&&r.Punkte===10));
});
test('admin overviews are inaccessible to class accounts and anonymous API callers',async t=>{
 const db=await setup(t);
 for(const role of ['anon','authenticated']){
  await db.exec('reset role;set role '+role);
  for(const view of ['admin_bewertungsmatrix','admin_einzelbewertungen','admin_zugaenge'])await assert.rejects(db.query('select * from public.'+view),/permission denied/);
 }
 await db.exec('reset role;set role service_role');assert.equal((await db.query('select * from public.admin_einzelbewertungen')).rows.length,4);
});

test('access overview shows registration and sign-in status without password data',async t=>{
 const db=await setup(t);const rows=(await db.query('select * from public.admin_zugaenge')).rows;assert.equal(rows.length,3);
 assert.equal(rows.find(r=>r.Name==='Tim').Passwortstatus,'Selbst festgelegt');
 assert.deepEqual(Object.keys(rows[0]),['Name','Login','Passwortstatus','Registriert am','Letzte Anmeldung']);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
const builder=new URL('../scripts/build.mjs',import.meta.url).pathname;
test('published HTML uses new asset URLs after script or style changes, avoiding mixed cached versions',async t=>{
 const dir=await mkdtemp(join(tmpdir(),'kuchenliga-build-'));t.after(()=>rm(dir,{recursive:true,force:true}));await mkdir(join(dir,'src'));
 for(const [path,body] of Object.entries({'index.html':'<link href="./styles.css"><script type="module" src="./src/app.js"></script>','styles.css':'body{color:blue}','config.js':'export const CONFIG={};','favicon.svg':'<svg/>','src/domain.js':'','src/photos.js':'','src/api.js':'','src/app.js':'globalThis.version=1;'}))await writeFile(join(dir,path),body);
 execFileSync(process.execPath,[builder],{cwd:dir});
 const first=await readFile(join(dir,'dist/index.html'),'utf8');const script1=first.match(/src="([^"]+)"/)[1],css1=first.match(/href="([^"]+)"/)[1];
 await writeFile(join(dir,'src/app.js'),'globalThis.version=2;');await writeFile(join(dir,'styles.css'),'body{color:red}');
 execFileSync(process.execPath,[builder],{cwd:dir});
 const second=await readFile(join(dir,'dist/index.html'),'utf8');const script2=second.match(/src="([^"]+)"/)[1],css2=second.match(/href="([^"]+)"/)[1];
 assert.notEqual(script1,script2);assert.notEqual(css1,css2);
 assert.ok((await readFile(join(dir,'dist',script2),'utf8')).includes('globalThis.version=2'));
 assert.equal(await readFile(join(dir,'dist',css2),'utf8'),'body{color:red}');
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {ClassApi} from '../src/api.js';
// Regression: a slow token refresh must never resurrect a logged-out identity.
test('pending refresh cannot recreate a session after logout',async t=>{
  const originalFetch=globalThis.fetch,originalStorage=globalThis.sessionStorage;
  const store=new Map();globalThis.sessionStorage={getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
  t.after(()=>{globalThis.fetch=originalFetch;globalThis.sessionStorage=originalStorage;});
  let release;const deferred=new Promise(r=>release=r);
  globalThis.fetch=async url=>url.includes('grant_type=refresh_token')?deferred:{ok:true,json:async()=>null};
  const api=new ClassApi({supabaseUrl:'https://class.supabase.co',publishableKey:'sb_publishable_test'});
  api.remember({expires_at:0,access_token:'old',refresh_token:'old-refresh',user:{id:'old-user'}});
  const pending=api.token().catch(()=>null);
  await api.logout();release({ok:true,json:async()=>({access_token:'new',refresh_token:'new-refresh',expires_in:3600,user:{id:'old-user'}})});
  await pending;assert.equal(api.session,null);assert.equal(store.size,0);
});
test('a slower earlier login cannot overwrite a newer identity',async t=>{
 const originalFetch=globalThis.fetch,originalStorage=globalThis.sessionStorage;
 const store=new Map();globalThis.sessionStorage={getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
 t.after(()=>{globalThis.fetch=originalFetch;globalThis.sessionStorage=originalStorage;});
 let release;const oldResponse=new Promise(r=>release=r);
 const session=id=>({ok:true,json:async()=>({access_token:id,refresh_token:'refresh-'+id,expires_in:3600,user:{id}})});
 globalThis.fetch=async(url,options)=>url.includes('/token')?(JSON.parse(options.body).email.startsWith('tim@')?oldResponse:session('berni')):{ok:true,json:async()=>[{login_id:'berni',participant_id:null}]};
 const api=new ClassApi({supabaseUrl:'https://class.supabase.co',publishableKey:'sb_publishable_test'});
 const older=api.login('tim','private').catch(()=>null);await api.login('berni','private');release(session('tim'));await older;
 assert.equal(api.session.user.id,'berni');
});

import test from 'node:test';
import assert from 'node:assert/strict';
const photos=await import('../src/photos.js').catch(()=>({}));
test('photo input only accepts bounded raster image files',()=>{
 assert.equal(typeof photos.validateCakePhoto,'function');
 for(const file of [{type:'image/svg+xml',size:100},{type:'text/html',size:100},{type:'image/jpeg',size:0},{type:'image/png',size:10*1024*1024+1}])assert.throws(()=>photos.validateCakePhoto(file));
 for(const type of ['image/jpeg','image/png','image/webp'])assert.doesNotThrow(()=>photos.validateCakePhoto({type,size:1024}));
});

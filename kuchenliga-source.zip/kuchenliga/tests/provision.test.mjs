import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const module=await import('../scripts/provision.mjs').catch(()=>({}));
test('provisioning creates and links class users, resumes without resetting passwords, keeps secrets local',async t=>{
  assert.equal(typeof module.provision,'function');
  const dir=await mkdtemp(join(tmpdir(),'kuchenliga-'));t.after(()=>rm(dir,{recursive:true,force:true}));
  const calls=[];let id=0;
  const request=async(path,body,options)=>{
    calls.push({path,body,options});
    if(path==='/auth/v1/admin/users'){assert.ok(body.password.length>=20);assert.equal(body.email_confirm,true);return {id:'test-'+(++id)};}
    if(path==='/rest/v1/members'||path==='/rest/v1/profiles')return [];
    throw Error('Unexpected path');
  };
  const opts={url:'https://class.supabase.co',key:'sb_secret_private',directory:dir,request,roster:[{id:'tim',name:'Tim'},{id:'livio',name:'Livio'}]};
  await module.provision(opts);await module.provision(opts);
  assert.equal(calls.filter(c=>c.path==='/auth/v1/admin/users').length,2);
  assert.equal(calls.filter(c=>c.path==='/rest/v1/members').length,2);
  const csv=await readFile(join(dir,'kuchenliga-zugaenge.csv'),'utf8');
  assert.ok(csv.includes('Tim'));assert.ok(!csv.includes('sb_secret_private'));
  assert.notEqual(calls[0].body.password,calls[3].body.password);
});
test('provisioning recovers a remotely created user after a lost response without resetting its password',async t=>{
 assert.equal(typeof module.provision,'function');
 const dir=await mkdtemp(join(tmpdir(),'kuchenliga-retry-'));t.after(()=>rm(dir,{recursive:true,force:true}));
 let remote=null,creates=0;
 const request=async(path,body,options={})=>{
  if(path.startsWith('/auth/v1/admin/users?'))return {users:remote?[remote]:[],next_page:null};
  if(path==='/auth/v1/admin/users'){creates++;remote={id:'recovered-user',email:body.email,app_metadata:body.app_metadata};throw Error('Connection lost after creation');}
  if(path==='/rest/v1/members'){assert.equal(body.user_id,'recovered-user');return [];}
  if(path==='/rest/v1/profiles')return [];
  throw Error('Unexpected path');
 };
 const options={url:'https://class.supabase.co',key:'sb_secret_private',directory:dir,request,roster:[{id:'tim',name:'Tim'}]};
 await assert.rejects(module.provision(options),/Connection lost/);
 const result=await module.provision(options);assert.equal(result.count,1);assert.equal(creates,1);
});

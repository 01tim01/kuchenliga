# Kuchenliga Implementation Plan

> **For agentic workers:** Implement inline with superpowers:executing-plans. User requested immediate execution.

**Goal:** German mobile-friendly class cake voting, hosted on GitHub Pages, with persistent immutable votes.
**Architecture:** Static HTML/CSS/ES modules call Supabase Auth and PostgREST. Postgres policies enforce class membership, scores, immutable unique votes and no self voting. No browser storage is trusted as proof of a vote.
**Tech Stack:** Browser JavaScript, Node test runner, Supabase Postgres/Auth, GitHub Actions/Pages, PGlite for database policy tests.
**Spec:** User conversation, including Joel Stocker and Joel Häusler and instruction to start now.

## Global Constraints
- Roster: Livio, Joel Stocker, Joel Häusler, Tim, Nico, Noemi, Anina, Kimo, Kyle, Raphael. Noemi once provisionally (10 people).
- Each person bakes once; one integer score 1–10 per other person's cake, irreversible for ordinary participants.
- Database enforces rules even for direct API calls. No public signup grants class membership.
- No real votes without configured backend. No invented rankings. Session stored only for current tab.
- Github Pages deployment is requested. Backend requires user's Supabase account; do not claim deployed until verified.

## Review Focus
- Duplicate insert and direct API tampering: database integration tests.
- Unknown or unauthenticated accounts: database integration tests.
- Failed save and expired session: UI tests and explicit retry states.
- Keyboard and narrow screen: browser checks at 390px and 1440px.
- Credentials never published: provisioning uses hidden terminal input; outputs ignored; build contains only allowlisted public files.

### Task 1: Voting rules and database
Files: src/domain.js, src/roster.js, supabase/schema.sql, tests/domain.test.mjs, tests/database.test.mjs.
- [ ] Write failing tests: invalid score, self vote, duplicate vote, no membership, spoofed voter, read privacy and immutable votes.
- [ ] Run npm test; observe missing implementation failures.
- [ ] Implement roster, validateVote({score,voterId,targetId,votes}), rankCakes(cakes,votes), database schema and restrictive policies.
- [ ] Run npm test; require all assertions pass against real Postgres engine.

### Task 2: Interface and API
Files: index.html, styles.css, src/app.js, src/api.js, config.js, tests/browser.mjs.
- [ ] Write browser tests for preview, navigation, mobile overflow, login, save confirmation, duplicate handling and logout.
- [ ] Run test:ui before implementing app; observe missing UI.
- [ ] Implement blue/red bakery scorecard design with CSS cake illustration, accessible dialogs, filters, secure login and server-backed saves.
- [ ] Run test:ui and inspect screenshots; API tests use external service stub only, database tests cover real policies.

### Task 3: Delivery and deployment
Files: scripts/build.mjs, scripts/serve.mjs, scripts/setup-users.mjs, .github/workflows/pages.yml, README.md, .gitignore.
- [ ] Build only public source files into dist; provide hidden-input account setup and private credential CSV, never upload it.
- [ ] Document Supabase SQL setup, disabled signups, password distribution, Pages and trust limits.
- [ ] Run full test suite, browser tests and build. Review security and deploy if repository/backend access is available.

## Accepted scope updates
- 12 accounts: original 10 names plus Maria and teacher Berni.
- 9 cake makers: Nico, Livio, Kimo, Kyle, Noemi, Maria, Anina, Joel Häusler, Tim. Joel Stocker, Raphael and Berni only vote.
- Baking schedule from user image transcribed into SCHEDULE and SQL; opening enforced by database Swiss date.
- Own profile emoji and color persisted with whitelist and owner-only mutation.
- Existing-key local helper invoked by user authorization; only secrets in memory, private random passwords in ignored private directory.

## Verification ledger
- Domain/database/session/provisioning test suite exercises direct API boundaries through actual Postgres roles.
- Browser scenarios cover preview, responsive layout, login, save, reload, duplicate, error, profiles, teacher, dates, logout races.
- Independent review found asynchronous session restoration, stale private results and lost account-creation response. Added regression tests and fixes.
- Ruling: publish compiled static files in repository root plus source archive because browser account 01tim01 differs from connector account; no credentials or private provisioning files included.

- User design revision: remove illustrated hero and decorative cake cards; compact functional list with name, date, aggregate points and voting action. Preserve all database rules and profile features.

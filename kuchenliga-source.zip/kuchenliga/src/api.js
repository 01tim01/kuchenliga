const SESSION_KEY='kuchenliga.session.v1';
export class ApiError extends Error { constructor(message,code,status){super(message);this.code=code;this.status=status;} }
export class ClassApi {
  constructor(config){
    this.url=config.supabaseUrl.replace(/\/$/,'');this.key=config.publishableKey;this.refreshing=null;this.generation=0;this.loginAttempt=0;
    try{this.session=JSON.parse(sessionStorage.getItem(SESSION_KEY)) || null;}catch{this.session=null;}
  }
  remember(session){this.generation++;this.session=session;if(session)sessionStorage.setItem(SESSION_KEY,JSON.stringify(session));else sessionStorage.removeItem(SESSION_KEY);}
  async raw(path,{method='GET',body,token}={}){
    const headers={apikey:this.key,'Content-Type':'application/json'};
    if(token) headers.Authorization=`Bearer ${token}`;
    if(['POST','PATCH'].includes(method) && path.startsWith('/rest/')) headers.Prefer='return=representation';
    let response;
    try { response=await fetch(this.url+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(15000)}); }
    catch { throw new ApiError('Keine Verbindung. Prüfe dein Internet und versuche es nochmals.','NETWORK',0); }
    const data=await response.json().catch(()=>null);
    if(!response.ok)throw new ApiError(data?.message || data?.msg || 'Die Anfrage konnte nicht abgeschlossen werden.',data?.code || data?.error_code,response.status);
    return data;
  }
  async login(participantId,password){
    const attempt=++this.loginAttempt;
    const data=await this.raw('/auth/v1/token?grant_type=password',{method:'POST',body:{email:`${participantId}@kuchenliga.invalid`,password}});
    if(attempt!==this.loginAttempt)throw new ApiError('Anmeldung überholt.','STALE',409);
    this.remember({...data,expires_at:Date.now()+data.expires_in*1000});
    try {const membership=await this.membership();if(attempt!==this.loginAttempt)throw new ApiError('Anmeldung überholt.','STALE',409);if(!membership) throw new ApiError('Kein Klassenzugang.','NO_MEMBER',403);if(!membership.registered_at)throw new ApiError('Bitte öffne zuerst deinen persönlichen Registrierungslink und lege dein Passwort fest.','REGISTRATION_REQUIRED',403);return membership;}
    catch(error){if(attempt===this.loginAttempt)this.remember(null);throw error;}
  }
  async token(){
    if(!this.session) throw new ApiError('Bitte melde dich erneut an.','SESSION',401);
    if(this.session.expires_at>Date.now()+30000)return this.session.access_token;
    if(!this.refreshing){
      const generation=this.generation;
      this.refreshing=this.raw('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:{refresh_token:this.session.refresh_token}})
        .then(data=>{if(this.generation!==generation)throw new ApiError('Sitzung geändert.','STALE',409);this.remember({...data,expires_at:Date.now()+data.expires_in*1000});return data.access_token;})
        .catch(error=>{if(this.generation===generation&&(error.status===400||error.status===401)){this.remember(null);throw new ApiError('Deine Sitzung ist abgelaufen. Bitte melde dich erneut an.','SESSION',401);}throw error;})
        .finally(()=>{this.refreshing=null;});
    }
    return this.refreshing;
  }
  async request(path,options={}){const user=this.session?.user?.id;const token=await this.token();if(!user||user!==this.session?.user?.id)throw new ApiError('Sitzung geändert.','STALE',409);return this.raw(path,{...options,token});}
  async membership(){return (await this.request('/rest/v1/members?select=participant_id,display_name,login_id,registered_at&user_id=eq.'+encodeURIComponent(this.session.user.id)))[0] || null;}
  async load(){
    const [ranking,votes,profiles]=await Promise.all([this.request('/rest/v1/rpc/leaderboard',{method:'POST',body:{}}),this.request('/rest/v1/votes?select=target_id,score'),this.request('/rest/v1/profiles?select=avatar,color')]);
    this.profileExists=profiles.length>0;
    return {ranking,profile:profiles[0]||{avatar:'🍰',color:'#eaf3fc'},votes:votes.map(v=>({...v,score:Number(v.score)}))};
  }
  async registration(token,action,password){return this.raw('/functions/v1/register',{method:'POST',body:{token,action,...(password?{password}:{})}});}
  async photos(){
    const paths=['nico','livio','kimo','kyle','noemi','maria','anina','joel-haeusler','tim'].map(id=>id+'.webp');
    const rows=await this.request('/storage/v1/object/sign/cake-photos',{method:'POST',body:{paths,expiresIn:3600}});
    const photos={};for(const row of rows){
      if(row.error||!paths.includes(row.path)||!row.signedURL?.startsWith('/object/sign/cake-photos/'))continue;
      photos[row.path.replace('.webp','')]=this.url+'/storage/v1'+row.signedURL+'&v='+Date.now();
    }return photos;
  }
  async uploadCakePhoto(participantId,blob){
    const token=await this.token();let response;
    try{response=await fetch(this.url+'/storage/v1/object/cake-photos/'+encodeURIComponent(participantId)+'.webp',{method:'POST',headers:{apikey:this.key,Authorization:'Bearer '+token,'Content-Type':'image/webp','x-upsert':'true','cache-control':'0'},body:blob,signal:AbortSignal.timeout(45000)});}
    catch{throw new ApiError('Upload nicht bestätigt. Bitte versuche es nochmals.','NETWORK',0);}
    if(!response.ok)throw new ApiError('Das Foto konnte nicht gespeichert werden.','UPLOAD',response.status);
  }
  async saveProfile(avatar,color){
    const rows=await this.request('/rest/v1/profiles'+(this.profileExists?'?user_id=eq.'+encodeURIComponent(this.session.user.id):''),{method:this.profileExists?'PATCH':'POST',body:this.profileExists?{avatar,color}:{user_id:this.session.user.id,avatar,color}});
    if(!rows?.length)throw new ApiError('Profil konnte nicht gespeichert werden.','PROFILE',403);
    this.profileExists=true;return rows[0];
  }
  async vote(targetId,score){
    return this.request('/rest/v1/votes',{method:'POST',body:{voter_id:this.session.user.id,target_id:targetId,score}});
  }
  async logout(){this.loginAttempt++;const token=this.session?.access_token;this.remember(null);if(token) await this.raw('/auth/v1/logout',{method:'POST',token}).catch(()=>{});}
}

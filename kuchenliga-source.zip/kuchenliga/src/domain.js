export const MEMBERS = [
  ['livio','Livio'], ['joel-stocker','Joel Stocker'], ['joel-haeusler','Joel Häusler'],
  ['tim','Tim'], ['nico','Nico'], ['noemi','Noemi'], ['anina','Anina'],
  ['kimo','Kimo'], ['kyle','Kyle'], ['raphael','Raphael'], ['maria','Maria'], ['berni','Berny']
].map(([id,name]) => ({id,name}));
export const SCHEDULE = {
  nico:'2026-11-13',livio:'2026-11-20',kimo:'2026-11-27',kyle:'2026-12-04',
  noemi:'2026-12-11',maria:'2026-12-18',anina:'2027-01-08','joel-haeusler':'2027-01-15',tim:'2027-01-22'
};
export const ROSTER = Object.entries(SCHEDULE).map(([id,date]) => ({...MEMBERS.find(p=>p.id===id),date}));
export const AVATARS=['🍰','🦊','🐸','🐼','🐱','🐻','🦋','🍓','👑','🦄','🐧','🌻'];
export const COLORS=['#eaf3fc','#f9e9ee','#e8f2ef','#fff1d5','#eeeaf5','#fae9df'];
export const swissToday = (now=new Date()) => {
  const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Zurich',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);
  const get=type=>parts.find(p=>p.type===type).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
};
export const isOpen = (cake,today=swissToday()) => Boolean(cake.date && cake.date<=today);
export function validateVote({score,voterId,targetId,votes=[]}) {
  if (!voterId || !targetId) throw new Error('Bitte melde dich zuerst an.');
  if (!Number.isInteger(score) || score < 1 || score > 10) throw new Error('Wähle eine ganze Punktzahl von 1 bis 10.');
  if (voterId === targetId) throw new Error('Deinen eigenen Kuchen kannst du nicht bewerten.');
  if (votes.some(v => v.target_id === targetId)) throw new Error('Diesen Kuchen hast du bereits bewertet.');
}
export function rankCakes(cakes) {
  const sorted = cakes.map(c => ({...c,average:c.average === null ? null : Number(c.average),vote_count:Number(c.vote_count)}))
    .sort((a,b) => (b.vote_count > 0) - (a.vote_count > 0) || (b.average ?? 0) - (a.average ?? 0) || a.name.localeCompare(b.name,'de'));
  let rank=0, previous=null;
  return sorted.map(c => {
    if (c.vote_count && c.average !== previous) { rank++; previous=c.average; }
    return {...c,rank:c.vote_count ? rank : null};
  });
}

export function validateCakePhoto(file){
 if(!file||!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('Bitte wähle ein JPG-, PNG- oder WebP-Bild.');
 if(!file.size||file.size>10*1024*1024)throw Error('Das Bild darf höchstens 10 MB gross sein.');
}
export async function prepareCakePhoto(file){
 validateCakePhoto(file);let bitmap;
 try{bitmap=await createImageBitmap(file);}catch{throw Error('Das Bild konnte nicht geöffnet werden. Bitte wähle ein anderes Foto.');}
 try{
  if(bitmap.width*bitmap.height>40000000)throw Error('Das Bild ist zu gross. Bitte wähle eine kleinere Version.');
  const scale=Math.min(1,1600/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
  canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);
  const encode=quality=>new Promise(resolve=>canvas.toBlob(resolve,'image/webp',quality));
  let result=await encode(.82);if(result?.size>1048576)result=await encode(.6);
  if(!result||result.type!=='image/webp'||result.size>1048576)throw Error('Das Foto konnte nicht verkleinert werden. Bitte wähle ein kleineres Bild.');
  return result;
 }finally{bitmap.close();}
}

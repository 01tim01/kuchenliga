begin;
alter table public.members add column if not exists registration_claim_id uuid;
alter table public.members add column if not exists registration_claim_until timestamptz;
create or replace function public.claim_free_registration(p_login_id text,p_claim_id uuid)
returns table(user_id uuid,display_name text,login_id text)
language sql security definer set search_path='' as $$
 update public.members m set registration_claim_id=p_claim_id,registration_claim_until=now()+interval '2 minutes'
 where m.login_id=p_login_id and m.registered_at is null
 and (m.registration_claim_until is null or m.registration_claim_until<now())
 returning m.user_id,m.display_name,m.login_id;
$$;
create or replace function public.finish_free_registration(p_login_id text,p_claim_id uuid)
returns boolean language plpgsql security definer set search_path='' as $$
declare account_id uuid;
begin
 update public.members m set registered_at=now(),registration_claim_id=null,registration_claim_until=null
 where m.login_id=p_login_id and m.registration_claim_id=p_claim_id and m.registered_at is null and m.registration_claim_until>now()
 returning m.user_id into account_id;
 if account_id is null then return false;end if;
 update public.registration_invites set used_at=now(),claimed_until=null where user_id=account_id;
 return true;
end;
$$;
create or replace function public.release_free_registration(p_login_id text,p_claim_id uuid)
returns void language sql security definer set search_path='' as $$
 update public.members set registration_claim_id=null,registration_claim_until=null
 where login_id=p_login_id and registration_claim_id=p_claim_id and registered_at is null;
$$;
revoke all on function public.claim_free_registration(text,uuid),public.finish_free_registration(text,uuid),public.release_free_registration(text,uuid) from public,anon,authenticated;
grant execute on function public.claim_free_registration(text,uuid),public.finish_free_registration(text,uuid),public.release_free_registration(text,uuid) to service_role;
commit;

begin;
update public.members set display_name='Berny' where login_id='berni';
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('profile-photos','profile-photos',false,1048576,array['image/webp'])
on conflict(id) do update set public=false,file_size_limit=1048576,allowed_mime_types=array['image/webp'];
drop policy if exists class_read_profile_photos on storage.objects;
create policy class_read_profile_photos on storage.objects for select to authenticated
 using (bucket_id='profile-photos' and exists(select 1 from public.members where user_id=(select auth.uid()) and registered_at is not null));
drop policy if exists own_profile_photo_insert on storage.objects;
create policy own_profile_photo_insert on storage.objects for insert to authenticated
 with check (bucket_id='profile-photos' and owner_id=(select auth.uid())::text
 and exists(select 1 from public.members m where m.user_id=(select auth.uid()) and m.registered_at is not null and storage.objects.name=m.login_id||'.webp'));
drop policy if exists own_profile_photo_update on storage.objects;
create policy own_profile_photo_update on storage.objects for update to authenticated
 using (bucket_id='profile-photos' and owner_id=(select auth.uid())::text
 and exists(select 1 from public.members m where m.user_id=(select auth.uid()) and m.registered_at is not null and storage.objects.name=m.login_id||'.webp'))
 with check (bucket_id='profile-photos' and owner_id=(select auth.uid())::text
 and exists(select 1 from public.members m where m.user_id=(select auth.uid()) and m.registered_at is not null and storage.objects.name=m.login_id||'.webp'));
drop policy if exists own_profile_photo_delete on storage.objects;
create policy own_profile_photo_delete on storage.objects for delete to authenticated
 using (bucket_id='profile-photos' and owner_id=(select auth.uid())::text
 and exists(select 1 from public.members m where m.user_id=(select auth.uid()) and m.registered_at is not null and storage.objects.name=m.login_id||'.webp'));
commit;

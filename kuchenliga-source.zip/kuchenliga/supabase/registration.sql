begin;
alter table public.members add column if not exists registered_at timestamptz;
create table if not exists public.registration_invites (
 token_hash text primary key check (token_hash ~ '^[a-f0-9]{64}$'),
 user_id uuid not null unique references public.members(user_id),
 expires_at timestamptz not null,
 used_at timestamptz
);
alter table public.registration_invites add column if not exists claim_id uuid;
alter table public.registration_invites add column if not exists claimed_until timestamptz;
alter table public.registration_invites enable row level security;
revoke all on public.registration_invites from public,anon,authenticated;
grant all on public.registration_invites to service_role;
-- A short lease prevents concurrent password updates without burning a failed invite.
drop function if exists public.consume_registration_invite(text);
create or replace function public.consume_registration_invite(p_token_hash text,p_claim_id uuid)
returns table(user_id uuid,display_name text,login_id text)
language sql security definer set search_path='' as $$
 with claimed as (
  update public.registration_invites i set claim_id=p_claim_id,claimed_until=now()+interval '2 minutes'
  where i.token_hash=p_token_hash and i.used_at is null and i.expires_at>now()
  and (i.claimed_until is null or i.claimed_until<now())
  and exists(select 1 from public.members m where m.user_id=i.user_id and m.registered_at is null)
  returning i.user_id
 ) select m.user_id,m.display_name,m.login_id from claimed c join public.members m on m.user_id=c.user_id;
$$;
create or replace function public.complete_registration_invite(p_token_hash text,p_claim_id uuid)
returns boolean language plpgsql security definer set search_path='' as $$
declare account_id uuid;
begin
 update public.registration_invites i set used_at=now(),claimed_until=null
 where i.token_hash=p_token_hash and i.claim_id=p_claim_id and i.used_at is null and i.claimed_until>now()
 returning i.user_id into account_id;
 if account_id is null then return false;end if;
 update public.members set registered_at=now() where user_id=account_id;
 return true;
end;
$$;
create or replace function public.release_registration_invite(p_token_hash text,p_claim_id uuid)
returns void language sql security definer set search_path='' as $$
 update public.registration_invites set claim_id=null,claimed_until=null
 where token_hash=p_token_hash and claim_id=p_claim_id and used_at is null;
$$;
revoke all on function public.consume_registration_invite(text,uuid),public.complete_registration_invite(text,uuid),public.release_registration_invite(text,uuid) from public,anon,authenticated;
grant execute on function public.consume_registration_invite(text,uuid),public.complete_registration_invite(text,uuid),public.release_registration_invite(text,uuid) to service_role;
commit;

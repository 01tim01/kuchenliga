begin;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('cake-photos','cake-photos',false,1048576,array['image/webp'])
on conflict(id) do update set public=false,file_size_limit=1048576,allowed_mime_types=array['image/webp'];
drop policy if exists class_read_cake_photos on storage.objects;
create policy class_read_cake_photos on storage.objects for select to authenticated
 using (bucket_id='cake-photos' and exists(select 1 from public.members where user_id=(select auth.uid()) and registered_at is not null));
drop policy if exists own_cake_photo_insert on storage.objects;
create policy own_cake_photo_insert on storage.objects for insert to authenticated
 with check (bucket_id='cake-photos' and owner_id=(select auth.uid())::text
 and exists(select 1 from public.members m join public.participants p on p.id=m.participant_id
 where m.user_id=(select auth.uid()) and m.registered_at is not null and p.active and storage.objects.name=m.participant_id||'.webp'));
drop policy if exists own_cake_photo_update on storage.objects;
create policy own_cake_photo_update on storage.objects for update to authenticated
 using (bucket_id='cake-photos' and owner_id=(select auth.uid())::text
 and exists(select 1 from public.members m join public.participants p on p.id=m.participant_id
 where m.user_id=(select auth.uid()) and m.registered_at is not null and p.active and storage.objects.name=m.participant_id||'.webp'))
 with check (bucket_id='cake-photos' and owner_id=(select auth.uid())::text
 and exists(select 1 from public.members m join public.participants p on p.id=m.participant_id
 where m.user_id=(select auth.uid()) and m.registered_at is not null and p.active and storage.objects.name=m.participant_id||'.webp'));
commit;

// Public endpoint: possession of a high-entropy single-use invite is required.
// Service credentials exist only in the Supabase Edge Function environment.
export async function handleRegistration(request,env,remote=fetch){
 const allowedOrigin='https://01tim01.github.io';
 const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':allowedOrigin,'Access-Control-Allow-Headers':'content-type,apikey,authorization','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store','Vary':'Origin'};
 const reply=(status,data)=>new Response(JSON.stringify(data),{status,headers});
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(request.method!=='POST')return reply(405,{error:'Methode nicht erlaubt.'});
 const origin=request.headers.get('origin');if(origin&&origin!==allowedOrigin)return reply(403,{error:'Nicht erlaubt.'});
 let body;try{const text=await request.text();if(text.length>8192)return reply(400,{error:'Eingabe zu lang.'});body=JSON.parse(text);}catch{return reply(400,{error:'Ungültige Anfrage.'});}
 if(!/^[A-Za-z0-9_-]{43}$/.test(body.token||''))return reply(400,{error:'Ungültiger Einladungslink.'});
 const info=body.action==='info';
 if(!info&&(typeof body.password!=='string'||body.password.length<12||body.password.length>128))return reply(400,{error:'Dein Passwort muss 12 bis 128 Zeichen lang sein.'});
 const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(body.token));
 const hash=[...new Uint8Array(digest)].map(n=>n.toString(16).padStart(2,'0')).join('');
 const base=env.SUPABASE_URL,key=env.SUPABASE_SERVICE_ROLE_KEY;
 if(!base||!key)return reply(503,{error:'Die Registrierung ist noch nicht bereit.'});
 const api=async(path,method='GET',payload)=>{
  const response=await remote(base+path,{method,headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:payload===undefined?undefined:JSON.stringify(payload),signal:AbortSignal.timeout(15000)});
  if(!response.ok)throw Error('REMOTE_FAILED');return response.json().catch(()=>null);
 };
 const claim=crypto.randomUUID();let claimed=false;
 try{
  if(info){
   const rows=await api('/rest/v1/registration_invites?token_hash=eq.'+hash+'&used_at=is.null&expires_at=gt.'+encodeURIComponent(new Date().toISOString())+'&select=members(display_name,login_id,registered_at)');
   const member=rows?.[0]?.members;if(!member||member.registered_at)return reply(409,{error:'Dieser Link wurde bereits verwendet oder ist abgelaufen.'});
   return reply(200,{name:member.display_name,login_id:member.login_id});
  }
  const rows=await api('/rest/v1/rpc/consume_registration_invite','POST',{p_token_hash:hash,p_claim_id:claim});
  const invite=rows?.[0];if(!invite)return reply(409,{error:'Dieser Link wurde bereits verwendet oder ist abgelaufen.'});
  claimed=true;
  await api('/auth/v1/admin/users/'+encodeURIComponent(invite.user_id),'PUT',{password:body.password});
  const completed=await api('/rest/v1/rpc/complete_registration_invite','POST',{p_token_hash:hash,p_claim_id:claim});
  if(!completed)throw Error('CLAIM_EXPIRED');
  return reply(200,{name:invite.display_name,login_id:invite.login_id});
 }catch{if(claimed){try{await api('/rest/v1/rpc/release_registration_invite','POST',{p_token_hash:hash,p_claim_id:claim});}catch{}}return reply(503,{error:'Die Registrierung wurde nicht bestätigt. Versuche es nochmals oder melde dich mit deinem gewählten Passwort an.'});}
}
if(typeof Deno!=='undefined')Deno.serve(request=>handleRegistration(request,Deno.env.toObject()));

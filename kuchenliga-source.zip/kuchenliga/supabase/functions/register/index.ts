// Free first registration for the pre-created class slots. Existing accounts are immutable here.
export async function handleRegistration(request,env,remote=fetch){
 const allowedOrigin='https://01tim01.github.io';
 const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':allowedOrigin,'Access-Control-Allow-Headers':'content-type,apikey,authorization','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store','Vary':'Origin'};
 const reply=(status,data)=>new Response(JSON.stringify(data),{status,headers});
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(request.method!=='POST')return reply(405,{error:'Methode nicht erlaubt.'});
 const origin=request.headers.get('origin');if(origin&&origin!==allowedOrigin)return reply(403,{error:'Nicht erlaubt.'});
 let body;try{const text=await request.text();if(text.length>8192)return reply(400,{error:'Eingabe zu lang.'});body=JSON.parse(text);}catch{return reply(400,{error:'Ungültige Anfrage.'});}
 if(body.action!=='signup'||!/^[-a-z]{2,40}$/.test(body.login_id||''))return reply(400,{error:'Bitte wähle deinen Namen aus.'});
 if(typeof body.password!=='string'||body.password.length<12||body.password.length>128)return reply(400,{error:'Dein Passwort muss 12 bis 128 Zeichen lang sein.'});
 const base=env.SUPABASE_URL,key=env.SUPABASE_SERVICE_ROLE_KEY;
 if(!base||!key)return reply(503,{error:'Die Registrierung ist noch nicht bereit.'});
 const api=async(path,payload,method='POST')=>{
  const response=await remote(base+path,{method,headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000)});
  if(!response.ok)throw Error('REMOTE_FAILED');return response.json().catch(()=>null);
 };
 const claim=crypto.randomUUID();let claimed=false;
 try{
  const rows=await api('/rest/v1/rpc/claim_free_registration',{p_login_id:body.login_id,p_claim_id:claim});
  const member=rows?.[0];
  if(!member)return reply(409,{error:'Dieser Name ist bereits registriert oder wird gerade eingerichtet. Melde dich mit deinem Passwort an oder versuche es in zwei Minuten nochmals.'});
  claimed=true;
  await api('/auth/v1/admin/users/'+encodeURIComponent(member.user_id),{password:body.password},'PUT');
  const completed=await api('/rest/v1/rpc/finish_free_registration',{p_login_id:body.login_id,p_claim_id:claim});
  if(!completed)throw Error('CLAIM_EXPIRED');
  return reply(200,{name:member.display_name,login_id:member.login_id});
 }catch{
  if(claimed){try{await api('/rest/v1/rpc/release_free_registration',{p_login_id:body.login_id,p_claim_id:claim});}catch{}}
  return reply(503,{error:'Die Registrierung wurde nicht bestätigt. Versuche es nochmals oder melde dich mit deinem gewählten Passwort an.'});
 }
}
if(typeof Deno!=='undefined')Deno.serve(request=>handleRegistration(request,Deno.env.toObject()));

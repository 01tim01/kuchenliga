-- Owner-only read-only overviews. The website's class accounts cannot read them.
begin;
-- Correct the display name without changing the existing login/account.
update public.members set display_name='Berny' where login_id='berni';
create or replace view public.admin_einzelbewertungen as
select m.display_name as "Abgestimmt von",p.name as "Kuchen von",v.score::integer as "Punkte",
       v.created_at at time zone 'Europe/Zurich' as "Abgegeben (Schweiz)"
from public.votes v join public.members m on m.user_id=v.voter_id
join public.participants p on p.id=v.target_id
order by v.created_at desc;

create or replace view public.admin_bewertungsmatrix as
with cells as (
 select m.user_id,m.display_name,m.registered_at,p.id as cake_id,p.baking_date,
        m.participant_id is distinct from p.id as eligible,v.score,
        case when v.score is not null then v.score::integer::text
             when m.participant_id=p.id then '—'
             when p.baking_date is null or p.baking_date>(now() at time zone 'Europe/Zurich')::date then '🔒'
             else 'Offen' end as cell
 from public.members m cross join public.participants p
 left join public.votes v on v.voter_id=m.user_id and v.target_id=p.id
 where p.active
)
select display_name as "Person",
 max(cell) filter(where cake_id='nico') as "Nico",
 max(cell) filter(where cake_id='livio') as "Livio",
 max(cell) filter(where cake_id='kimo') as "Kimo",
 max(cell) filter(where cake_id='kyle') as "Kyle",
 max(cell) filter(where cake_id='noemi') as "Noemi",
 max(cell) filter(where cake_id='maria') as "Maria",
 max(cell) filter(where cake_id='anina') as "Anina",
 max(cell) filter(where cake_id='joel-haeusler') as "Joel Häusler",
 max(cell) filter(where cake_id='tim') as "Tim",
 count(score)::integer as "Abgegeben",
 count(*) filter(where eligible and baking_date<=(now() at time zone 'Europe/Zurich')::date and score is null)::integer as "Noch offen",
 case when registered_at is not null then 'Registriert' else 'Noch nicht registriert' end as "Zugang"
from cells group by user_id,display_name,registered_at order by display_name;

create or replace view public.admin_zugaenge as
select m.display_name as "Name",m.login_id as "Login",
       case when m.registered_at is not null then 'Selbst festgelegt' else 'Noch nicht festgelegt' end as "Passwortstatus",
       m.registered_at at time zone 'Europe/Zurich' as "Registriert am",
       u.last_sign_in_at at time zone 'Europe/Zurich' as "Letzte Anmeldung"
from public.members m left join auth.users u on u.id=m.user_id
order by m.display_name;

-- Supabase default grants must be explicitly removed in the same transaction.
revoke all on public.admin_einzelbewertungen,public.admin_bewertungsmatrix,public.admin_zugaenge from public,anon,authenticated;
grant select on public.admin_einzelbewertungen,public.admin_bewertungsmatrix,public.admin_zugaenge to service_role;
comment on view public.admin_bewertungsmatrix is 'Private Adminübersicht: Zeile=abstimmende Person, Spalte=Kuchen. Zahl=Punkte, Offen=noch nicht bewertet, 🔒=Termin noch nicht erreicht, —=eigener Kuchen.';
comment on view public.admin_einzelbewertungen is 'Private Adminübersicht aller abgegebenen Einzelbewertungen mit Namen und Schweizer Zeit. Nur für Projektverwaltung, nicht für Klassen-Zugänge.';
comment on view public.admin_zugaenge is 'Private Zugangsübersicht mit Status und letzter Anmeldung. Passwörter und Passwort-Hashes werden nicht ausgegeben.';
commit;

import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {CONFIG} from '../config.js';
const links=JSON.parse(await readFile('private/registration-links.json','utf8'));
for(const link of links){
 const response=await fetch(CONFIG.supabaseUrl+'/functions/v1/register',{method:'POST',headers:{apikey:CONFIG.publishableKey,'Content-Type':'application/json',Origin:'https://01tim01.github.io'},body:JSON.stringify({token:link.token,action:'info'}),signal:AbortSignal.timeout(20000)});
 const result=await response.json();assert.equal(response.status,200,JSON.stringify({login:link.login,result}));assert.equal(result.login_id,link.login);assert.equal(result.name,link.name);
}
const invalid=await fetch(CONFIG.supabaseUrl+'/functions/v1/register',{method:'POST',headers:{apikey:CONFIG.publishableKey,'Content-Type':'application/json'},body:JSON.stringify({token:'invalid',action:'info'})});assert.equal(invalid.status,400);
console.log(`${links.length} live invitation links verified without consuming them; anonymous gateway reaches token validation.`);

import {readFile,writeFile,mkdir,copyFile,rm} from 'node:fs/promises';
// Allowlist: private setup, credentials, test assets and dev dependencies can never be deployed.
await rm('dist',{recursive:true,force:true});await mkdir('dist',{recursive:true});
for(const f of ['styles.css','config.js','favicon.svg'])await copyFile(f,'dist/'+f);
const sources=await Promise.all(['src/domain.js','src/api.js','src/app.js'].map(f=>readFile(f,'utf8')));
const bundle=sources.map(s=>s.replace(/^import .*;\n/gm,'').replace(/^export /gm,'')).join('\n');
await writeFile('dist/app.js',"import {CONFIG} from './config.js';\n"+bundle);
await writeFile('dist/index.html',(await readFile('index.html','utf8')).replace('./src/app.js','./app.js'));
await writeFile('dist/.nojekyll','');
console.log('Built static site in dist/ (6 public files).');

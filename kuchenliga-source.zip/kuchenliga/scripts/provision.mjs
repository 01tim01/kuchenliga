import {randomBytes} from 'node:crypto';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {MEMBERS,ROSTER} from '../src/domain.js';
export async function provision({url,key,directory,roster=MEMBERS,request,onProgress=()=>{}}){
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url))throw Error('Ungültige Supabase-Projekt-URL.');
  if(!key?.startsWith('sb_secret_')&&!key?.startsWith('eyJ'))throw Error('Bitte den geheimen Supabase-Schlüssel eingeben.');
  await mkdir(directory,{recursive:true,mode:0o700});
  const checkpoint=join(directory,'provisioning.json');
  let saved;try{saved=JSON.parse(await readFile(checkpoint,'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;saved={url,users:[]};}
  if(saved.url!==url)throw Error('Dieser private Ordner gehört zu einem anderen Projekt.');
  const persist=async()=>{
    await writeFile(checkpoint,JSON.stringify(saved,null,2),{mode:0o600});
    const csv='Name;Login;Passwort\n'+saved.users.map(u=>[u.name,u.login,u.password].join(';')).join('\n')+'\n';
    await writeFile(join(directory,'kuchenliga-zugaenge.csv'),'\uFEFF'+csv,{mode:0o600});
  };
  const send=request|| (async(path,body,options={})=>{
    const headers={apikey:key,'Content-Type':'application/json',...options.headers};
    if(key.startsWith('eyJ'))headers.Authorization='Bearer '+key;
    const response=await fetch(url+path,{method:options.method||'POST',headers,body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
    const data=await response.json().catch(()=>null);
    if(!response.ok)throw Error(`Supabase ${response.status}: ${data?.msg||data?.message||'Einrichtung fehlgeschlagen.'}`);
    return data;
  });
  for(const person of roster){
    let entry=saved.users.find(u=>u.login===person.id);
    if(!entry){
      entry={login:person.id,name:person.name,password:randomBytes(18).toString('base64url'),linked:false,setup_id:randomBytes(16).toString('hex')};
      // Persist password before remote creation, so interruption cannot lose it.
      saved.users.push(entry);await persist();
    }
    if(!entry.user_id && entry.creation_started){
      for(let page=1;page<=100;page++){
        const listing=await send('/auth/v1/admin/users?page='+page+'&per_page=1000',undefined,{method:'GET'});
        const user=listing.users?.find(u=>u.email?.toLowerCase()===`${person.id}@kuchenliga.invalid`);
        if(user){if(user.app_metadata?.kuchenliga_setup_id!==entry.setup_id)throw Error('Ein bestehendes Konto hat eine andere Herkunft. Bitte nicht zurücksetzen.');entry.user_id=user.id;await persist();break;}
        if(!listing.next_page)break;
      }
    }
    if(!entry.user_id){
      entry.creation_started=true;await persist();
      const user=await send('/auth/v1/admin/users',{email:`${person.id}@kuchenliga.invalid`,password:entry.password,email_confirm:true,app_metadata:{kuchenliga_setup_id:entry.setup_id}});
      entry.user_id=user.id||user.user?.id;if(!entry.user_id)throw Error('Benutzer-ID fehlt in der Supabase-Antwort.');await persist();
    }
    if(!entry.linked){
      await send('/rest/v1/members',{user_id:entry.user_id,participant_id:ROSTER.some(p=>p.id===person.id)?person.id:null,display_name:person.name,login_id:person.id},{headers:{Prefer:'resolution=ignore-duplicates'}});
      entry.linked=true;await persist();
    }
    if(!entry.profile){
      await send('/rest/v1/profiles',{user_id:entry.user_id,avatar:'🍰',color:'#eaf3fc'},{headers:{Prefer:'resolution=ignore-duplicates'}});
      entry.profile=true;await persist();
    }
    onProgress(person.name);
  }
  return {count:saved.users.length,path:join(directory,'kuchenliga-zugaenge.csv')};
}

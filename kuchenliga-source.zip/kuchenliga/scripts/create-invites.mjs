import {randomBytes,createHash} from 'node:crypto';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
export async function createInvites({url,key,directory}){
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url)||(!key?.startsWith('sb_secret_')&&!key?.startsWith('eyJ')))throw Error('Ungültiger Projektschlüssel.');
 const send=async(path,method='GET',body)=>{
  const headers={apikey:key,'Content-Type':'application/json',Prefer:'resolution=merge-duplicates'};if(key.startsWith('eyJ'))headers.Authorization='Bearer '+key;
  const response=await fetch(url+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
  if(!response.ok)throw Error('Supabase '+response.status+': Einladungen konnten nicht erstellt werden.');return response.json().catch(()=>null);
 };
 await mkdir(directory,{recursive:true,mode:0o700});
 let saved=[];try{saved=JSON.parse(await readFile(join(directory,'registration-links.json'),'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;}
 const members=await send('/rest/v1/members?select=user_id,display_name,login_id,registered_at');
 for(const member of members){
  if(member.registered_at)continue;let entry=saved.find(p=>p.user_id===member.user_id);
  if(!entry){entry={user_id:member.user_id,name:member.display_name,login:member.login_id,token:randomBytes(32).toString('base64url')};saved.push(entry);}
  entry.url='https://01tim01.github.io/kuchenliga/#invite='+entry.token;
  await writeFile(join(directory,'registration-links.json'),JSON.stringify(saved,null,2),{mode:0o600});
  await send('/rest/v1/registration_invites?on_conflict=user_id','POST',{user_id:member.user_id,token_hash:createHash('sha256').update(entry.token).digest('hex'),expires_at:new Date(Date.now()+30*86400000).toISOString(),used_at:null,claim_id:null,claimed_until:null});
 }
 const active=saved.filter(e=>members.some(m=>m.user_id===e.user_id&&!m.registered_at));
 const csv='\uFEFFName;Registrierungslink\n'+active.map(e=>e.name+';'+e.url).join('\n')+'\n';
 await writeFile(join(directory,'kuchenliga-registrierungslinks.csv'),csv,{mode:0o600});
 return {count:active.length,path:join(directory,'kuchenliga-registrierungslinks.csv')};
}

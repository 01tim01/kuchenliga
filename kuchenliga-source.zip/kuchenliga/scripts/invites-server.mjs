import http from 'node:http';
import {randomBytes} from 'node:crypto';
import {resolve} from 'node:path';
import {CONFIG} from '../config.js';
import {createInvites} from './create-invites.mjs';
const nonce=randomBytes(24).toString('hex');let running=false,done=false;
const origin='http://127.0.0.1:4174';
const html=`<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kuchenliga · Zugänge einrichten</title><style>body{font:16px system-ui;max-width:580px;margin:70px auto;padding:24px;color:#244b83;background:#f2f7fc}h1{font-size:36px;letter-spacing:-1px}p{line-height:1.7}label{display:block;margin:25px 0 10px;font-weight:700}input{box-sizing:border-box;width:100%;padding:15px;border:1px solid #bccde0;border-radius:8px;font:inherit}button{margin-top:18px;padding:16px 24px;border:0;border-radius:8px;background:#d92f4b;color:white;font:700 15px system-ui;cursor:pointer}button:disabled{opacity:.5}#status{white-space:pre-wrap;background:#fff;padding:20px;border-radius:8px}small{line-height:1.6;display:block}</style><h1>Persönliche Registrierungslinks.</h1><p>Damit nur eure Klasse abstimmen kann, erstellt dieser lokale Helfer einmalige Registrierungslinks. Jede Person legt damit ihr eigenes Passwort fest. Die Links landen ausschliesslich in einer privaten Datei auf deinem Computer.</p><p>Öffne bei Supabase <strong>Project Settings → API Keys → Secret keys</strong> und kopiere den vorhandenen geheimen Schlüssel.</p><form id="setup"><label for="key">Geheimer Supabase-Schlüssel</label><input id="key" type="password" autocomplete="off" required placeholder="sb_secret_…"><small>Wird nur an dein Projekt wfnesqtbgdghssaqiolk.supabase.co gesendet, nicht gespeichert und nicht veröffentlicht.</small><button id="submit">Registrierungslinks erstellen</button></form><p id="status" role="status" hidden></p><script nonce="${nonce}">document.querySelector('#setup').onsubmit=async e=>{e.preventDefault();const button=document.querySelector('#submit'),status=document.querySelector('#status'),input=document.querySelector('#key');button.disabled=true;status.hidden=false;status.textContent='Registrierungslinks werden erstellt…';try{const key=input.value;input.value='';const response=await fetch('/setup/${nonce}',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})});const data=await response.json();if(!response.ok)throw Error(data.error);status.textContent=data.message;document.querySelector('#setup').hidden=true;}catch(error){status.textContent=error.message;button.disabled=false;}};</script></html>`;
const server=http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',`default-src 'none'; script-src 'nonce-${nonce}'; style-src 'unsafe-inline'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'`);
 if(req.headers.host!=='127.0.0.1:4174'){res.writeHead(403);res.end();return;}
 if(req.method==='GET'&&req.url==='/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);return;}
 if(req.method!=='POST'||req.url!==`/setup/${nonce}`||req.headers.origin!==origin){res.writeHead(403);res.end();return;}
 res.setHeader('Content-Type','application/json');
 if(running||done){res.writeHead(409);res.end(JSON.stringify({error:done?'Die Zugänge sind bereits eingerichtet.':'Einrichtung läuft bereits.'}));return;}
 running=true;
 try{
   let input='';for await(const chunk of req){input+=chunk;if(input.length>10000)throw Error('Eingabe zu lang.');}
   const {key}=JSON.parse(input);
   const result=await createInvites({url:CONFIG.supabaseUrl,key:key.trim(),directory:resolve('private')});done=true;
   res.writeHead(200);res.end(JSON.stringify({message:`Fertig: ${result.count} Registrierungslinks erstellt. Die private Linkliste liegt hier:\n${result.path}\n\nDu kannst diesen Tab jetzt schliessen.`}));
   console.log(`SETUP_COMPLETE: ${result.count} invites; private invitation file created.`);
 }catch(error){res.writeHead(400);res.end(JSON.stringify({error:error.message}));console.log('SETUP_FAILED: Einrichtung bitte im lokalen Tab erneut versuchen.');}
 finally{running=false;}
});
server.listen(4174,'127.0.0.1',()=>console.log(origin));

import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {CONFIG} from '../config.js';
const {users}=JSON.parse(await readFile('private/provisioning.json','utf8'));
async function request(path,{token,body,method='GET'}={}){
 const response=await fetch(CONFIG.supabaseUrl+path,{method,headers:{apikey:CONFIG.publishableKey,'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
 const data=await response.json().catch(()=>null);return {status:response.status,data};
}
assert.equal(users.length,12);
for(const login of ['tim','berni']){
 const user=users.find(p=>p.login===login);const auth=await request('/auth/v1/token?grant_type=password',{method:'POST',body:{email:login+'@kuchenliga.invalid',password:user.password}});
 assert.equal(auth.status,200,'Login must succeed for '+login);const token=auth.data.access_token;
 const membership=await request('/rest/v1/members?select=participant_id,login_id',{token});assert.equal(membership.data.length,1);assert.equal(membership.data[0].login_id,login);assert.equal(membership.data[0].participant_id,login==='berni'?null:'tim');
 const ranking=await request('/rest/v1/rpc/leaderboard',{token,method:'POST',body:{}});assert.equal(ranking.status,200);assert.equal(ranking.data.length,9);assert.ok(ranking.data.every(p=>Number(p.vote_count)===0));
 const votes=await request('/rest/v1/votes?select=target_id,score',{token});assert.equal(votes.data.length,0);
 const future=await request('/rest/v1/votes',{token,method:'POST',body:{voter_id:auth.data.user.id,target_id:'kimo',score:8}});assert.equal(future.status,403,'Future vote must be denied');
 const immutable=await request('/rest/v1/votes?voter_id=eq.'+auth.data.user.id,{token,method:'PATCH',body:{score:1}});assert.equal(immutable.status,403,JSON.stringify(immutable.data));
 await request('/auth/v1/logout',{token,method:'POST'});
 console.log(login+': login, membership, 9 cakes, privacy, future-date lock and immutability verified.');
}
const anon=await request('/rest/v1/rpc/leaderboard',{method:'POST',body:{}});assert.ok([401,403].includes(anon.status));
console.log('Live checks passed. No production votes were created.');

import {createInterface} from 'node:readline/promises';
import {Writable} from 'node:stream';
import {resolve} from 'node:path';
import {provision} from './provision.mjs';
import {CONFIG} from '../config.js';
let muted=false;
const output=new Writable({write(chunk,encoding,callback){if(!muted)process.stdout.write(chunk,encoding);callback();}});
const rl=createInterface({input:process.stdin,output,terminal:true});
try{
 process.stdout.write('Geheimer Supabase-Key (Eingabe unsichtbar, wird nicht gespeichert): ');muted=true;
 const key=await rl.question('');muted=false;process.stdout.write('\n');rl.close();
 const result=await provision({url:CONFIG.supabaseUrl,key:key.trim(),directory:resolve('private'),onProgress:name=>console.log(name+' eingerichtet')});
 console.log(`${result.count} Zugänge angelegt. Private Passwortliste: ${result.path}`);
}catch(error){muted=false;rl.close();console.error(error.message);process.exitCode=1;}

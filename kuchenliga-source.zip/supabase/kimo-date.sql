-- Kimos Kuchen ist ab 26. November 2026 bewertbar.
update public.participants set baking_date = '2026-11-26' where id = 'kimo';

# Password recovery Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans.

**Goal:** Generate an administrator-created one-time reset link for Joel Stocker, with reusable recovery page for future requests.
**Architecture:** Supabase Auth generates/verifies recovery tokens. Standalone static page uses the recovered session to update only the password. No email service.
**Tech Stack:** Existing JS, Supabase Auth.
**Spec:** docs/superpowers/specs/2026-11-26-password-recovery-design.md

- [x] Write failing tests for weak/mismatched input, expired tokens, password update and retry.
- [x] Implement memory-only recovery flow and standalone reset page.
- [ ] Run full suite and browser recovery checks, build, publish.
- [ ] Generate only Joel Stocker's link, preserving existing account/votes.
- [ ] Hand link to user without consuming it; stop local helper.

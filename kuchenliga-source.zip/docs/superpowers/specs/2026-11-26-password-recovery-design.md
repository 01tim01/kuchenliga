# Password recovery

User requests administrator-created one-time links on demand, starting with Joel Stocker. No email provider or recovery-contact setup. Internal logins, accounts, registration and votes stay unchanged. Supabase generates and verifies single-use recovery tokens; a standalone page accepts the user-chosen new password. Tokens and passwords stay in memory only, the URL fragment is removed immediately, and the token is exchanged only on deliberate form submission. Service keys stay in a local helper and are never published.

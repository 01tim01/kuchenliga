import {readFile,writeFile,mkdir,copyFile,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
// Explicit allowlist: private setup files and credentials can never be deployed.
await rm('dist',{recursive:true,force:true});await mkdir('dist',{recursive:true});
for(const f of ['config.js','favicon.svg'])await copyFile(f,'dist/'+f);
const sources=await Promise.all(['src/domain.js','src/photos.js','src/api.js','src/app.js'].map(f=>readFile(f,'utf8')));
const bundle="import {CONFIG} from './config.js';\n"+sources.map(s=>s.replace(/^import .*;\n/gm,'').replace(/^export /gm,'')).join('\n');
const css=await readFile('styles.css','utf8');
const hash=text=>createHash('sha256').update(text).digest('hex').slice(0,12);
const appName=`app.${hash(bundle)}.js`,cssName=`styles.${hash(css)}.css`;
await writeFile('dist/'+appName,bundle);await writeFile('dist/'+cssName,css);
const html=(await readFile('index.html','utf8')).replace('./src/app.js','./'+appName).replace('./styles.css','./'+cssName);
const recoverySources=await Promise.all(['src/password-reset.js','src/recovery-page.js'].map(f=>readFile(f,'utf8')));
const recoveryBundle="import {CONFIG} from './config.js';\n"+recoverySources.map(s=>s.replace(/^import .*;\n/gm,'').replace(/^export /gm,'')).join('\n');
const recoveryName=`recovery.${hash(recoveryBundle)}.js`;
await writeFile('dist/'+recoveryName,recoveryBundle);
await writeFile('dist/passwort.html',(await readFile('passwort.html','utf8')).replace('./src/recovery-page.js','./'+recoveryName));
await writeFile('dist/index.html',html);await writeFile('dist/.nojekyll','');
console.log(`Built static site in dist/: ${appName}, ${cssName}, index.html and public config/assets.`);
